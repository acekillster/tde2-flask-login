from flask import Blueprint, render_template, request
from flask_login import login_required

actuators_bp = Blueprint('actuators', __name__, template_folder='templates')

devices = {
    "Lampada": "Luz",
    "Motor": "MotorDC"
}

@actuators_bp.route('/register_actuators')
@login_required
def register_actuators():
    return render_template('register_actuators.html')

@actuators_bp.route('/add_actuators', methods=['POST'])
@login_required
def add_actuators():
    name = request.form.get('actuator_name')
    typ = request.form.get('actuator_type')
    if name and typ:
        devices[name] = typ
    return render_template('actuators.html', devices=devices)

@actuators_bp.route('/list_actuators')
@login_required
def list_actuators():
    return render_template('actuators.html', devices=devices)

@actuators_bp.route('/remove_actuators')
@login_required
def remove_actuators():
    return render_template('remove_actuators.html', devices=devices)

@actuators_bp.route('/del_actuator', methods=['POST'])
@login_required
def del_actuator():
    name = request.form.get('actuator_name')
    if name:
        devices.pop(name, None)
    return render_template('actuators.html', devices=devices)
