from flask import Flask, redirect, url_for
from flask_login import LoginManager
import login
from sensors import sensors_bp
from actuators import actuators_bp

app = Flask(__name__)
app.config['SECRET_KEY'] = 'minha_chave_secreta'

login_manager = LoginManager()
login_manager.login_view = 'login.login_page'
login_manager.init_app(app)

@login_manager.user_loader
def load_user(user_id):
    if user_id in login.users:
        return login.User(user_id)
    return None

app.register_blueprint(login.login_bp)
app.register_blueprint(sensors_bp)
app.register_blueprint(actuators_bp)

@app.route('/')
def index():
    return redirect(url_for('login.login_page'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000, debug=True)
