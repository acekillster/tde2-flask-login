from flask import Blueprint, render_template, request, redirect, url_for
from flask_login import UserMixin, login_user, logout_user, login_required
from jinja2 import TemplateNotFound

login_bp = Blueprint('login', __name__, template_folder='templates')

users = {
    'user1': '1234',
    'user2': '12345'
}

class User(UserMixin):
    def __init__(self, username):
        self.id = username

@login_bp.route('/login')
def login_page():
    return render_template('login.html')

@login_bp.route('/validated_user', methods=['POST'])
def validated_user():
    username = request.form.get('user')
    password = request.form.get('password')
    if username in users and users[username] == password:
        user = User(username)
        login_user(user)
        return redirect(url_for('login.home'))
    return '<h1>Usuário ou senha inválidos!</h1>'

@login_bp.route('/home')
@login_required
def home():
    return render_template('home.html')

@login_bp.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login.login_page'))

@login_bp.route('/list_users')
@login_required
def list_users():
    try:
        return render_template('user.html', devices=users)
    except TemplateNotFound:
        items = ''.join(f'<li>{nome} - {senha}</li>' for nome, senha in users.items())
        html = f'''<html>
<head><title>Lista de Usuários</title></head>
<body>
<h2>Usuários Cadastrados</h2>
<ul>{items}</ul>
<p><a href="{url_for('login.home')}">Voltar para o menu</a></p>
</body>
</html>'''
        return html

@login_bp.route('/register_user')
@login_required
def register_user():
    return render_template('register_user.html')

@login_bp.route('/add_user', methods=['POST'])
@login_required
def add_user():
    username = request.form.get('user')
    password = request.form.get('password')
    if username and password:
        users[username] = password
    return redirect(url_for('login.list_users'))

@login_bp.route('/remove_user')
@login_required
def remove_user():
    try:
        return render_template('remove_user.html', devices=users)
    except TemplateNotFound:
        items = ''.join(f'<option>{nome}</option>' for nome in users.keys())
        html = f'''<html><body>
<h2>Remover Usuário</h2>
<form action="{url_for('login.del_user')}" method="post">
<select name="user">{items}</select>
<p><input type="submit" value="Deletar"></p>
</form></body></html>'''
        return html

@login_bp.route('/del_user', methods=['POST'])
@login_required
def del_user():
    username = request.form.get('user')
    if username:
        users.pop(username, None)
    return redirect(url_for('login.list_users'))
