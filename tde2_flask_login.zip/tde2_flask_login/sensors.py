from flask import Blueprint, render_template, request
from flask_login import login_required

sensors_bp = Blueprint('sensors', __name__, template_folder='templates')

devices = {
    "TemperaturaSensor": "Temperatura",
    "HumidadeSensor": "Umidade"
}

@sensors_bp.route('/register_sensors')
@login_required
def register_sensors():
    return render_template("register_sensors.html")

@sensors_bp.route('/add_sensors', methods=['POST'])
@login_required
def add_sensors():
    name = request.form.get('sensor_name')
    typ = request.form.get('sensor_type')
    if name and typ:
        devices[name] = typ
    return render_template('sensors.html', devices=devices)

@sensors_bp.route('/list_sensors')
@login_required
def list_sensors():
    return render_template('sensors.html', devices=devices)

@sensors_bp.route('/remove_sensors')
@login_required
def remove_sensors():
    return render_template('remove_sensors.html', devices=devices)

@sensors_bp.route('/del_sensor', methods=['POST'])
@login_required
def del_sensor():
    name = request.form.get('sensor_name')
    if name:
        devices.pop(name, None)
    return render_template('sensors.html', devices=devices)
